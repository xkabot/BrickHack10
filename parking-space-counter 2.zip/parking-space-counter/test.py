import cv2

mask = './mask_crop.png'
video_path = 'data/movies_test_boxes.mp4'

cap = cv2.VideoCapture(video_path)


ret = True

while ret:
    ret, frame = cap.read()

    cv2.imshow("frame", frame)

    if cv2.waitKey(25) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()