# parking-space-counter

In this video I show you how to build a parking space detector and counter with computer vision !

[![Watch the video](https://img.youtube.com/vi/F-884J2mnOY/0.jpg)](https://www.youtube.com/watch?v=F-884J2mnOY)

## data

You can download the data and model I used in this tutorial [here](https://drive.google.com/drive/folders/1CjEFWihRqTLNUnYRwHXxGAVwSXF2k8QC?usp=sharing).
